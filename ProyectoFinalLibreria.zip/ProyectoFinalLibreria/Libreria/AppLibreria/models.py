from django.db import models
from django.contrib.auth.models import User


# Create your models here.


class Categoria(models.Model):
    nombre = models.CharField(max_length=200)

    def __str__(self):
        return self.nombre


class Libro(models.Model):
    def __str__(self):
        return self.nombre

    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    nombre = models.CharField(max_length=200)
    categoria = models.ForeignKey(
        Categoria, on_delete=models.CASCADE, null=True, blank=True
    )
    precio = models.IntegerField()
    descripcion = models.TextField(null=True, blank=True)
    imagenLibro = models.ImageField(
        null=True, blank=True, upload_to="AppLibreria/static/Applibreria/assets/img"
    )


class ContactoModelo(models.Model):
    nombre = models.CharField(max_length=200)
    apellido = models.CharField(max_length=200)
